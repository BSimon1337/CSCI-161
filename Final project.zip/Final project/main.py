'''
Beau Simon
CSCI L02
Final project - Part II
Online Student - 0869416
'''

import module1

if __name__ == "__main__":
    players_list = module1.input_data()
    print("\nPlayers list:", players_list)
