'''
Beau Simon
CSCI L02
Final project - Part IV
Online Student - 0869416
'''

class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year


class Entry(Car):
    def __init__(self, make, model, year, driver, number):
        Car.__init__(self, make, model, year)
        self.driver = driver
        self.number = number

    def printEntry(self):
        print(f"Make: {self.make}, Model: {self.model}, Year: {self.year}, Driver: {self.driver}, Number: {self.number}")


def main():
    entries = []

    for i in range(3):
        print(f"\nEntry {i + 1}:")
        make = input("Enter car make: ")
        model = input("Enter car model: ")
        year = int(input("Enter car year: "))
        driver = input("Enter driver name: ")
        number = int(input("Enter entry number: "))

        entry = Entry(make, model, year, driver, number)
        entries.append(entry)

    print("\nEntries:")
    for entry in entries:
        entry.printEntry()

if __name__ == "__main__":
    main()
