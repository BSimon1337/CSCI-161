'''
Beau Simon
CSCI L02
Final project - Part I
Online Student - 0869416
'''
# module1.py
def input_data():
    players = []

    for i in range(3):
        try:
            last_name = input(f"Enter player {i + 1}'s last name: ")
            number = int(input(f"Enter player {i + 1}'s number: "))
            players.append((last_name, number))
        except Exception as e:
            print(f"Error: {e}. Setting player {i + 1} name to 'none' and number to 0.")
            players.append(('none', 0))

    return players
