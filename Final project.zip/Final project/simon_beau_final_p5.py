'''
Beau Simon
CSCI L02
Final project - Part V
Online Student - 0869416
'''

import itertools

def get_dictionary_words():
    try:
        with open("dictionary.txt", "r") as f:
            words = f.read().splitlines()
        print(f"Dictionary loaded with {len(words)} words.")
        return words
    except FileNotFoundError:
        print("Error: dictionary.txt not found. Make sure the file exists and is in the same directory as this script.")
        return []

def find_words(input_str, dictionary):
    found_words = set()
    for i in range(1, len(input_str) + 1):
        for perm in itertools.permutations(input_str, i):
            candidate = ''.join(perm)
            if candidate in dictionary:
                found_words.add(candidate)

    return found_words

def main():
    input_str = input("Enter a string: ")
    dictionary = get_dictionary_words()
    found_words = find_words(input_str, dictionary)

    if found_words:
        for word in found_words:
            print(f"Found: {word}")
    else:
        print("No matches found.")

if __name__ == "__main__":
    main()

