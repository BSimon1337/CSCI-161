'''
Beau Simon
CSCI L02
Final project - Part III
Online Student - 0869416
'''
import os

#Had to add this so it would read my file. Omit if needed

os.chdir(r"C:\Users\beau.a.simon\OneDrive - North Dakota University System\Desktop\CSCI\Final project")

def main():
    try:
        with open("textfile1.txt", "r") as file1:
            contents = file1.readlines()
            num_lines = len(contents)

        print(f"The file contains {num_lines} lines.")

        with open("textfile2.txt", "w") as file2:
            for line in contents:
                file2.write(line)

    except FileNotFoundError:
        print("Error: textfile1.txt not found. Make sure the file exists and is in the same directory as this script.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
